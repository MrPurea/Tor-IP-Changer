import time, os
x = '2'
while True:
      time.sleep(int(x))
      os.system("killall -HUP tor")
